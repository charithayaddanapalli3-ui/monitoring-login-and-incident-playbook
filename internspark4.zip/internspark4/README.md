# Monitoring and Logging Demo

## Components

* Docker
* Prometheus
* Grafana
* Application Container

## Start Monitoring Stack

docker-compose up -d

## Access Services

Grafana:
http://localhost:3000

Prometheus:
http://localhost:9090

Application:
http://localhost:8080

## Alerting

Alert Rule:
HighCPUUsage

Triggers when CPU exceeds configured threshold.

## Logging

View logs:

docker logs app

Export logs:

docker logs app > app.log

## Incident Response

Refer to incident-runbook.md for detection, mitigation, and post-mortem procedures.
