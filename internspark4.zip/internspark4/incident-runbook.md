# Incident Response Runbook

## Incident: Service Down

### Detection

* Grafana dashboard shows service unavailable
* Prometheus alert triggered
* Users report application inaccessible

### Investigation

Check running containers:

docker ps

Check application logs:

docker logs app

Check resource usage:

docker stats

### Mitigation

Restart container:

docker restart app

If container fails repeatedly:

docker-compose up -d --force-recreate

### Verification

Open application endpoint:

http://localhost:8080

Verify dashboard metrics return to normal.

### Post-Mortem

1. Record timeline of incident.
2. Identify root cause.
3. Document corrective actions.
4. Update monitoring thresholds.
5. Share findings with team.

---

## Incident: High CPU Usage

### Detection

Prometheus HighCPUUsage alert fires.

### Investigation

docker stats

Identify offending container.

### Mitigation

Restart service or scale resources.

### Verification

CPU usage returns below threshold.

### Post-Mortem

Analyze workload spike and optimize application performance.
